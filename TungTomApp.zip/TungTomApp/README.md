# TrollModPoke 2.0 — menu nổi chạy nền (không còn WebView)

App không còn nhúng trình duyệt. Thay vào đó:
- **Nút 🍤 nổi** + **menu** hiện đè lên mọi ứng dụng (kể cả Chrome / Firefox), chạy nền bằng foreground service.
- Game chạy trong **trình duyệt của bạn**. App nói chuyện với trang qua một máy chủ nhỏ chỉ nghe ở `127.0.0.1:38765`
  (mọi yêu cầu phải có token ngẫu nhiên riêng của máy bạn; trang chỉ được gọi hàm `PSBot.*`, `PSLite.*`, `__TT.*`).
- Viền nút 🍤 xanh lá = đã có trang game kết nối.

## Build APK
GitHub Actions: upload cả thư mục (giữ `.github/`) → tab *Actions* → *Build APK* → tải artifact `TungTom-apk`.
Hoặc Android Studio: Build → Build APK(s).

## Dùng
1. Mở app → cấp **quyền hiển thị trên ứng dụng khác** → menu nổi tự bật.
2. Kết nối trình duyệt (chọn 1):
   - **Firefox / Kiwi + Violentmonkey (đầy đủ tính năng):** bấm *Sao chép link userscript*, dán vào thanh địa chỉ trình duyệt đó, cài.
     Mở pokesurvivor.com là tự kết nối. Script chạy ở document-start nên hook canvas của bot hoạt động.
   - **Chrome (hạn chế):** Chrome Android không có userscript. Dùng *bookmarklet* (tạo dấu trang, dán nội dung đã sao chép làm URL,
     vào game gõ tên dấu trang vào thanh địa chỉ rồi chạm gợi ý). Script nạp sau khi trang tải xong nên
     Gacha / Upgrade / Shop / Đăng nhập chạy được; **Bot tự chơi và Giảm lag cần hook lúc trang bắt đầu tải nên thường không chạy**.

## Menu (5 tab)
🎮 Bot · 🎰 Gacha/Shop · ⚡ Giảm lag · 👤 Tài khoản · ⚙ Cài đặt (mở game, tải lại trang, link kết nối, giữ sáng màn hình).
Tab "Màn nhỏ" đã bỏ vì menu giờ nằm đè trên chính trang game thật.

## Cấu trúc
- `OverlayService.java` — nút nổi, menu, gọi lệnh vào trang. `LocalServer.java` — cầu nối. `Cfg.java` — token + link.
- `assets/comm.js` — phía trang (long-poll). `bridge.js`, `TungTom_user.js` — như bản cũ.
- Gốc bot: damhieu2808/PokeSurvivorTool (MIT).
