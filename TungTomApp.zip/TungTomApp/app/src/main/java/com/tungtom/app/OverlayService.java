package com.tungtom.app;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.text.InputType;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.security.KeyStore;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Dịch vụ nền (foreground) giữ: nút nổi 🍤 + menu nổi hiện đè lên trình duyệt + cầu nối cục bộ tới trang game.
 * Không còn WebView: game chạy trong trình duyệt của bạn, app điều khiển qua LocalServer.
 */
public class OverlayService extends Service {
    static final String ACTION_STOP = "com.tungtom.app.STOP";
    static final String ACTION_MENU = "com.tungtom.app.MENU";
    static volatile boolean running = false;

    private static final String HOME_DEFAULT = "https://pokesurvivor.com/";
    private static final String HOME_DOOF = "https://pokesurvivor.doofcraft.com/";

    private SharedPreferences prefs;
    private WindowManager wm;
    private ImageView fab;
    private GradientDrawable fabBg;
    private WindowManager.LayoutParams fabLp;
    private LocalServer server;
    private long lastNoConnToast = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable fabTick = new Runnable() {
        @Override public void run() {
            refreshFab();
            ui.postDelayed(this, 2000);
        }
    };

    // Service không có theme: bọc bằng theme của app để Button / Switch / Dialog hiển thị như trước
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(new ContextThemeWrapper(base, R.style.Theme_TungTom));
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("tt", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        running = true;
        startFg();
        if (!Settings.canDrawOverlays(this)) {
            toast("Chưa cấp quyền hiển thị trên ứng dụng khác. Mở app TrollModPoke để cấp.");
            stopSelf();
            return;
        }
        server = new LocalServer(this, Cfg.token(this));
        server.setHelloListener(this::onHello);
        if (!server.start()) toast("Không mở được cổng " + LocalServer.PORT + " (đang bị app khác dùng?)");
        setupFab();
        ui.post(fabTick);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(a)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_MENU.equals(a) && fab != null) openMenu();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (menuDlg != null) { try { menuDlg.dismiss(); } catch (Exception ignored) {} }
        if (fab != null) { try { wm.removeView(fab); } catch (Exception ignored) {} }
        if (server != null) server.stop();
        running = false;
        super.onDestroy();
    }

    // ---------- thông báo foreground (giữ app sống khi sang trình duyệt) ----------
    private void startFg() {
        String ch = "tt_overlay";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(ch, "TrollModPoke", NotificationManager.IMPORTANCE_LOW));
        int fl = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pm = PendingIntent.getService(this, 1, new Intent(this, OverlayService.class).setAction(ACTION_MENU), fl);
        PendingIntent ps = PendingIntent.getService(this, 2, new Intent(this, OverlayService.class).setAction(ACTION_STOP), fl);
        PendingIntent po = PendingIntent.getActivity(this, 3, new Intent(this, MainActivity.class), fl);
        Notification.Action open = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Mở menu", pm).build();
        Notification.Action stop = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Dừng", ps).build();
        Notification n = new Notification.Builder(this, ch)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("TrollModPoke đang chạy nền")
                .setContentText("Chạm nút 🍤 nổi trên màn hình để mở menu")
                .setContentIntent(po)
                .setOngoing(true)
                .addAction(open)
                .addAction(stop)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    // ---------- nút nổi 🍤 (kéo được, chạm = mở menu); viền xanh lá khi đã có trang game kết nối ----------
    @SuppressLint("ClickableViewAccessibility")
    private void setupFab() {
        fab = new ImageView(this);
        fab.setImageResource(R.drawable.logo_sq);
        fab.setScaleType(ImageView.ScaleType.CENTER_CROP);
        fabBg = new GradientDrawable();
        fabBg.setShape(GradientDrawable.OVAL);
        fabBg.setColor(0xFF000000);
        fabBg.setStroke(dp(2), 0xFF4DA3FF);
        fab.setBackground(fabBg);
        fab.setClipToOutline(true);
        fab.setAlpha(0.92f);

        fabLp = new WindowManager.LayoutParams(dp(48), dp(48),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        fabLp.gravity = Gravity.TOP | Gravity.START;
        int[] sz = screenSize();
        fabLp.x = Math.max(0, Math.min(sz[0] - dp(48), prefs.getInt("fabX", sz[0] - dp(60))));
        fabLp.y = Math.max(0, Math.min(sz[1] - dp(48), prefs.getInt("fabY", dp(120))));
        if (prefs.getBoolean("keepAwake", true)) fabLp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;

        final float[] down = new float[4];
        final boolean[] moved = new boolean[1];
        fab.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX(); down[1] = e.getRawY();
                    down[2] = fabLp.x;     down[3] = fabLp.y;
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - down[0], dy = e.getRawY() - down[1];
                    if (Math.abs(dx) + Math.abs(dy) > dp(8)) moved[0] = true;
                    if (moved[0]) {
                        int[] s = screenSize();
                        fabLp.x = (int) Math.max(0, Math.min(s[0] - dp(48), down[2] + dx));
                        fabLp.y = (int) Math.max(0, Math.min(s[1] - dp(48), down[3] + dy));
                        try { wm.updateViewLayout(fab, fabLp); } catch (Exception ignored) {}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (moved[0]) prefs.edit().putInt("fabX", fabLp.x).putInt("fabY", fabLp.y).apply();
                    else openMenu();
                    return true;
                default:
                    return true;
            }
        });
        try {
            wm.addView(fab, fabLp);
        } catch (Exception e) {
            toast("Không hiện được nút nổi: " + e.getMessage());
        }
    }

    private void refreshFab() {
        if (fabBg == null || server == null) return;
        fabBg.setStroke(dp(2), server.connected() ? 0xFF4DD08A : 0xFF4DA3FF);
    }

    private void applyKeepAwake() {
        if (fab == null || fabLp == null) return;
        if (prefs.getBoolean("keepAwake", true)) fabLp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        else fabLp.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        try { wm.updateViewLayout(fab, fabLp); } catch (Exception ignored) {}
    }

    // ---------- trang game vừa kết nối: đẩy cấu hình + tự đăng nhập ----------
    private void onHello(String pid, String host) {
        rpc(pid, "call", "__TT.hide", ja(prefs.getBoolean("hidePanel", true)), null, null);
        rpc(pid, "call", "__TT.game.setOpt", ja(j("autoUpgrade", prefs.getBoolean("autoUpgrade", false))), null, null);
        if (prefs.getBoolean("autoLogin", false)) {
            String[] c = loadCred(siteKey(host));
            long now = System.currentTimeMillis();
            // tối đa 1 lần / 60 giây để không lặp khi đăng nhập sai
            if (c != null && now - prefs.getLong("autoLoginAt", 0) > 60000) {
                prefs.edit().putLong("autoLoginAt", now).apply();
                rpc(pid, "call", "__TT.autoLogin", ja(c[0], c[1]), null, null);
            }
        }
        refreshFab();
    }

    // ---------- gọi hàm trong trang qua cầu nối ----------
    private void rpc(String pid, String op, String path, JSONArray args, Object val, Consumer<Object> cb) {
        if (server == null) { if (cb != null) cb.accept(null); return; }
        JSONObject c = new JSONObject();
        try {
            c.put("op", op);
            if (path != null) c.put("path", path);
            if (args != null) c.put("args", args);
            if (val != null) c.put("val", val);
        } catch (JSONException e) {
            return;
        }
        server.send(c, pid, cb);
    }

    private boolean needConn(boolean say) {
        if (server != null && server.connected()) return true;
        if (say) {
            long n = SystemClock.uptimeMillis();
            if (n - lastNoConnToast > 3000) {
                lastNoConnToast = n;
                toast("Chưa có trang game nào kết nối. Mở game trong trình duyệt đã cài script (xem tab Cài đặt).");
            }
        }
        return false;
    }

    private void call(String path, Object... args) {
        if (needConn(true)) rpc(null, "call", path, ja(args), null, null);
    }

    private void callQ(String path, Object... args) {
        if (needConn(false)) rpc(null, "call", path, ja(args), null, null);
    }

    private void callCb(String path, Consumer<Object> cb, Object... args) {
        rpc(null, "call", path, ja(args), null, cb);
    }

    private void getv(String path, Consumer<Object> cb) {
        rpc(null, "get", path, null, null, cb);
    }

    private void setv(String path, Object val) {
        if (needConn(true)) rpc(null, "set", path, null, val, null);
    }

    private JSONObject j(String k, Object v) {
        JSONObject o = new JSONObject();
        try { o.put(k, v); } catch (JSONException ignored) {}
        return o;
    }

    private JSONArray ja(Object... xs) {
        JSONArray a = new JSONArray();
        for (Object x : xs) a.put(x);
        return a;
    }

    // ---------- tiện ích cửa sổ ----------
    private int[] screenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getCurrentWindowMetrics().getBounds();
            return new int[]{b.width(), b.height()};
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private void showOver(Dialog dlg) {
        Window w = dlg.getWindow();
        if (w != null) w.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        dlg.show();
    }

    private void copy(String label, String text, String done) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
        toast(done);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            toast("Không mở được trình duyệt");
        }
    }

    // ---------- tài khoản: lưu mã hoá bằng khoá Android Keystore ----------
    private SecretKey credKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias("tt_cred")) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder("tt_cred", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey("tt_cred", null);
    }

    private String enc(String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, credKey());
        byte[] ct = c.doFinal(plain.getBytes("UTF-8"));
        return Base64.encodeToString(c.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
    }

    private String dec(String s) throws Exception {
        String[] p = s.split(":");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, credKey(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), "UTF-8");
    }

    /** "doof" cho pokesurvivor.doofcraft.com, còn lại "main": mỗi trang lưu một tài khoản riêng. */
    private String siteKey(String host) {
        return host != null && host.contains("doofcraft") ? "doof" : "main";
    }

    private String[] loadCred(String site) {
        String s = prefs.getString("cred_" + site, null);
        if (s == null) return null;
        try {
            JSONObject o = new JSONObject(dec(s));
            return new String[]{o.optString("u"), o.optString("p")};
        } catch (Exception e) { return null; }
    }

    private boolean saveCred(String site, String u, String p) {
        try {
            JSONObject o = new JSONObject();
            o.put("u", u);
            o.put("p", p);
            prefs.edit().putString("cred_" + site, enc(o.toString())).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    private void runLogin(String u, String p, boolean auto) {
        call(auto ? "__TT.autoLogin" : "__TT.login", u, p);
    }

    private String unq(String v) {
        if (v == null || v.equals("null")) return "";
        try {
            Object o = new JSONTokener(v).nextValue();
            return o instanceof String ? (String) o : String.valueOf(o);
        } catch (Exception e) { return v; }
    }

    private void toast(String t) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show();
    }


    // ---------- menu native: tab ở cạnh trái (ngang) hoặc đáy (dọc), nội dung cuộn, nút to ----------
    private Dialog menuDlg;
    private LinearLayout menuBody;
    private TextView menuStatus;
    private Button[] tabBtns;
    private int curTab = 0;
    private boolean liteAdv = false;

    private static final String[] TAB_ICON = {"🎮", "🎰", "⚡", "👤", "⚙"};
    private static final String[] TAB_NAME = {"Bot", "Gacha/Shop", "Giảm lag", "Tài khoản", "Cài đặt"};

    private void openMenu() {
        if (menuDlg != null && menuDlg.isShowing()) return;
        if (!Settings.canDrawOverlays(this)) { toast("Chưa cấp quyền hiển thị trên ứng dụng khác"); return; }
        showMenu();
    }

    private void showMenu() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        menuDlg = d;
        final int[] sz = screenSize();
        final boolean land = sz[0] > sz[1];

        LinearLayout rootCol = new LinearLayout(this);
        rootCol.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF141A22);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF1F4A7A);

        // đầu menu: tên + trạng thái bot + nút đóng
        LinearLayout head = row();
        head.setPadding(dp(14), dp(6), dp(6), dp(2));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.addView(title("TrollModPoke"));
        menuStatus = muted("Đang đọc trạng thái…");
        ht.addView(menuStatus);
        ImageView hl = new ImageView(this);
        hl.setImageResource(R.drawable.logo_sq);
        hl.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable hbg = new GradientDrawable();
        hbg.setColor(Color.BLACK);
        hbg.setCornerRadius(dp(10));
        hbg.setStroke(dp(1), 0xFF4DA3FF);
        hl.setBackground(hbg);
        hl.setClipToOutline(true);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(dp(42), dp(42));
        hlp.rightMargin = dp(10);
        head.addView(hl, hlp);
        head.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = btn("✕", v -> d.dismiss());
        close.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(44)));
        head.addView(close);
        rootCol.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // nội dung cuộn
        menuBody = new LinearLayout(this);
        menuBody.setOrientation(LinearLayout.VERTICAL);
        menuBody.setPadding(dp(12), dp(2), dp(12), dp(12));
        ScrollView sv = new ScrollView(this);
        sv.addView(menuBody);

        // thanh tab
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(land ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(4), dp(2), dp(4), dp(4));
        tabBtns = new Button[TAB_NAME.length];
        for (int i = 0; i < TAB_NAME.length; i++) {
            final int idx = i;
            Button tb = btn(TAB_ICON[i] + "\n" + TAB_NAME[i], v -> selectTab(idx));
            tb.setTextSize(11);
            tb.setMinimumHeight(dp(46));
            LinearLayout.LayoutParams tp = land ? new LinearLayout.LayoutParams(-1, 0, 1) : new LinearLayout.LayoutParams(0, -2, 1);
            tp.setMargins(dp(2), dp(2), dp(2), dp(2));
            tb.setLayoutParams(tp);
            tabs.addView(tb);
            tabBtns[i] = tb;
        }
        if (land) {
            LinearLayout mid = new LinearLayout(this);
            mid.setOrientation(LinearLayout.HORIZONTAL);
            mid.addView(tabs, new LinearLayout.LayoutParams(dp(84), -1));
            mid.addView(sv, new LinearLayout.LayoutParams(0, -1, 1));
            rootCol.addView(mid, new LinearLayout.LayoutParams(-1, 0, 1));
        } else {
            rootCol.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
            rootCol.addView(tabs, new LinearLayout.LayoutParams(-1, -2));
        }

        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(bg);
        frame.setClipToOutline(true);
        ImageView bgv = new ImageView(this);
        bgv.setImageResource(R.drawable.menu_bg);
        bgv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(bgv, new FrameLayout.LayoutParams(-1, -1));
        View scrim = new View(this);
        scrim.setBackgroundColor(0xB0060B14);            // phủ tối để chữ và nút dễ đọc
        frame.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        frame.addView(rootCol, new FrameLayout.LayoutParams(-1, -1));
        d.setContentView(frame);
        d.setOnDismissListener(x -> { menuDlg = null; });
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            w.setLayout(Math.min(sz[0] - dp(16), dp(land ? 660 : 440)), (int) (sz[1] * (land ? 0.94f : 0.92f)));
            w.setGravity(Gravity.CENTER);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        d.show();
        selectTab(curTab);
    }

    private void fetchState(final Consumer<JSONObject> cb) {
        rpc(null, "state", null, null, null, v -> cb.accept(v instanceof JSONObject ? (JSONObject) v : new JSONObject()));
    }

    private void selectTab(final int i) {
        if (menuDlg == null) return;
        curTab = i;
        for (int k = 0; k < tabBtns.length; k++) paint(tabBtns[k], k == i);
        menuBody.removeAllViews();
        switch (i) {
            case 0: fetchState(st -> { if (menuDlg != null && curTab == i) buildBotTab(st); }); break;
            case 1: buildGameTab(); break;
            case 2: fetchState(st -> { if (menuDlg != null && curTab == i) buildLiteTab(st); }); break;
            case 3: buildAccountTab(); break;
            default: buildAppTab(); break;
        }
    }

    private void updateStatus(JSONObject st) {
        if (server == null || !server.connected()) {
            menuStatus.setText("Chưa có trang game kết nối (xem tab Cài đặt)");
            return;
        }
        JSONObject bot = st.optJSONObject("bot");
        if (bot == null) { menuStatus.setText("Bot: chưa tải (đợi game vào xong rồi mở lại menu)"); return; }
        menuStatus.setText("Bot: " + (bot.optBoolean("on") ? "ĐANG CHẠY" : "dừng")
                + " · ván " + (bot.optInt("done") + 1) + (bot.optInt("target") > 0 ? "/" + bot.optInt("target") : ""));
    }

    // ----- tab 1: Bot -----
    private void buildBotTab(JSONObject st) {
        updateStatus(st);
        final Dialog d = menuDlg;
        JSONObject bot = st.optJSONObject("bot");
        JSONObject run = st.optJSONObject("run");
        String host = st.optString("host", "");
        LinearLayout col = menuBody;

        // số ván: − [5] +
        LinearLayout rr = row();
        rr.addView(muted("Số ván (0 = vô hạn)"), new LinearLayout.LayoutParams(0, -2, 1));
        final EditText runs = new EditText(this);
        runs.setInputType(InputType.TYPE_CLASS_NUMBER);
        runs.setText(String.valueOf(prefs.getInt("runs", 5)));
        runs.setTextColor(Color.WHITE);
        runs.setTextSize(16);
        runs.setGravity(Gravity.CENTER);
        runs.setSingleLine(true);
        runs.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_DONE);
        Button minus = btn("−", v -> runs.setText(String.valueOf(Math.max(0, parseRuns(runs) - 1))));
        Button plus = btn("+", v -> runs.setText(String.valueOf(parseRuns(runs) + 1)));
        minus.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(44)));
        plus.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(44)));
        rr.addView(minus);
        rr.addView(runs, new LinearLayout.LayoutParams(dp(64), -2));
        rr.addView(plus);
        col.addView(rr);

        LinearLayout r1 = row();
        r1.addView(bigBtn("▶ Chơi", 0xFF1F4A33, 0xFF7EE2A8, v -> {
            int n = parseRuns(runs);
            prefs.edit().putInt("runs", n).apply();
            call("PSBot.play", n);
            d.dismiss();
        }));
        r1.addView(bigBtn("■ Dừng", 0xFF4D2429, 0xFFFF9A9A, v -> { call("PSBot.stop"); d.dismiss(); }));
        col.addView(r1);
        LinearLayout r2 = row();
        r2.addView(bigBtn("⏸ Tạm dừng", 0xFF1D2530, 0xFFE6EBF2, v -> { call("PSBot.pause"); d.dismiss(); }));
        r2.addView(bigBtn("⏯ Tiếp tục", 0xFF1D2530, 0xFFE6EBF2, v -> { call("PSBot.resume"); d.dismiss(); }));
        col.addView(r2);

        col.addView(sw("Hiện overlay debug", bot != null && bot.optBoolean("debug"),
                (b, on) -> setv("PSBot.state.debug", on)));

        if (host.contains("doofcraft")) {
            col.addView(section("Chế độ ván (doofcraft)"));
            col.addView(muted("Chế độ"));
            col.addView(segment(new String[]{"Game", "Normal", "Waves"},
                    idx(new String[]{"game", "normal", "waves"}, run == null ? "game" : run.optString("mode", "game")),
                    i -> setRun("mode", new String[]{"game", "normal", "waves"}[i])));
            col.addView(muted("Độ khó"));
            col.addView(segment(new String[]{"Game", "Easy", "Medium", "Hard"},
                    idx(new String[]{"game", "easy", "medium", "hard"}, run == null ? "game" : run.optString("difficulty", "game")),
                    i -> setRun("difficulty", new String[]{"game", "easy", "medium", "hard"}[i])));
            col.addView(muted("HYPER"));
            col.addView(segment(new String[]{"Game", "Tắt", "Bật"},
                    idx(new String[]{"game", "off", "on"}, run == null ? "game" : run.optString("hyper", "game")),
                    i -> setRun("hyper", new String[]{"game", "off", "on"}[i])));
        }
    }

    private int parseRuns(EditText e) {
        try { return Math.max(0, Integer.parseInt(e.getText().toString().trim())); }
        catch (Exception ex) { return 5; }
    }

    // ----- tab 3: Gacha / Upgrade / Shop: bấm đúng nút trên màn hình game, như người chơi -----
    // Theo dõi trạng thái do bridge.js báo (Xong / Không thấy / Lỗi...) rồi hiện toast
    private void pollGame(final int tries) {
        ui.postDelayed(() -> getv("__TT.game.status", v -> {
            String t = v == null ? "" : String.valueOf(v);
            if (t.isEmpty()) return;
            boolean fin = t.startsWith("Xong") || t.startsWith("Không") || t.startsWith("Lỗi") || t.startsWith("Upgrade:") || t.startsWith("Đã mở");
            if (fin) toast(t);
            else if (tries > 0) pollGame(tries - 1);
        }), 2000);
    }

    private void showScan(String text) {
        final String txt = text.replace("\"", "");
        ScrollView sv = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText(txt);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        tv.setPadding(dp(14), dp(8), dp(14), dp(8));
        sv.addView(tv);
        AlertDialog ad = new AlertDialog.Builder(this).setTitle("Giao diện game đang mở").setView(sv)
                .setPositiveButton("Sao chép", (dd, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("giao-dien-game", txt));
                    toast("Đã sao chép");
                })
                .setNegativeButton("Đóng", null).create();
        showOver(ad);
    }

    private void buildGameTab() {
        final Dialog d = menuDlg;
        LinearLayout col = menuBody;
        col.addView(muted("Các nút dưới bấm giúp bạn ngay trên màn hình game. Hãy đang ở menu chính của game."));

        // ----- Gacha -----
        col.addView(section("Gacha"));
        col.addView(muted("Chọn Gen (thế hệ) trong màn gacha của game"));
        col.addView(segment(new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9"},
                Math.max(0, Math.min(8, prefs.getInt("gen", 1) - 1)),
                i -> prefs.edit().putInt("gen", i + 1).apply()));
        col.addView(muted("Số lượt quay"));
        final int[] times = {1, 5, 10, 20};
        int ti = 0;
        for (int i = 0; i < times.length; i++) if (times[i] == prefs.getInt("gTimes", 1)) ti = i;
        col.addView(segment(new String[]{"1", "5", "10", "20"}, ti, i -> prefs.edit().putInt("gTimes", times[i]).apply()));
        col.addView(muted("Mỗi lượt"));
        col.addView(segment(new String[]{"Quay x1", "Quay x10"}, prefs.getInt("gCount", 1) >= 10 ? 1 : 0,
                i -> prefs.edit().putInt("gCount", i == 1 ? 10 : 1).apply()));
        col.addView(bigBtn1("🎰 Quay gacha", 0xFF16304F, 0xFF7DBBFF, v -> {
            d.dismiss();
            toast("Đang quay gacha…");
            call("__TT.game.gacha", prefs.getInt("gen", 1), prefs.getInt("gTimes", 1), prefs.getInt("gCount", 1));
            pollGame(60);
        }));
        col.addView(bigBtn1("Chỉ mở màn gacha của game", 0xFF1D2530, 0xFFE6EBF2, v -> {
            d.dismiss();
            call("__TT.game.open", "gacha");
        }));

        // ----- Upgrade -----
        col.addView(section("Upgrade"));
        col.addView(bigBtn1("⬆ Cộng hết điểm Upgrade ngay", 0xFF16304F, 0xFF7DBBFF, v -> {
            d.dismiss();
            toast("Đang cộng điểm Upgrade…");
            call("__TT.game.upgrade");
            pollGame(60);
        }));
        col.addView(sw("Tự cộng sau mỗi ván (khi về menu)", prefs.getBoolean("autoUpgrade", false), (b, on) -> {
            prefs.edit().putBoolean("autoUpgrade", on).apply();
            callQ("__TT.game.setOpt", j("autoUpgrade", on));
        }));

        // ----- Shop -----
        col.addView(section("Shop"));
        col.addView(bigBtn1("🛒 Mở Shop của game", 0xFF1D2530, 0xFFE6EBF2, v -> {
            d.dismiss();
            call("__TT.game.openShop");
        }));

        // ----- công cụ -----
        col.addView(section("Công cụ"));
        col.addView(bigBtn1("🔍 Dò giao diện game", 0xFF1D2530, 0xFFE6EBF2, v -> {
            if (!needConn(true)) return;
            callCb("__TT.game.scan", r -> showScan(r == null ? "Không đọc được (trang chưa tải xong?)" : String.valueOf(r)));
        }));
        col.addView(muted("Nếu nút nào không bấm đúng: mở màn đó trong game, bấm \"Dò giao diện game\", sao chép và gửi lại để chỉnh cho khớp."));
    }

    // ----- tab 3: Giảm lag -----
    private void buildLiteTab(JSONObject st) {
        updateStatus(st);
        final Dialog d = menuDlg;
        JSONObject lite = st.optJSONObject("lite");
        LinearLayout col = menuBody;
        if (lite == null) { col.addView(muted("Chưa có trang game kết nối hoặc trang chưa tải xong.")); return; }

        col.addView(muted("Chọn nhanh"));
        LinearLayout pr = row();
        pr.addView(bigBtn("Tắt", 0xFF1D2530, 0xFFE6EBF2, v -> { call("PSLite.preset", "off"); selectTab(2); }));
        pr.addView(bigBtn("Nhẹ", 0xFF1D2530, 0xFFE6EBF2, v -> { call("PSLite.preset", "light"); selectTab(2); }));
        pr.addView(bigBtn("Mạnh", 0xFF1D2530, 0xFFE6EBF2, v -> { call("PSLite.preset", "strong"); selectTab(2); }));
        pr.addView(bigBtn("Tối đa", 0xFF1D2530, 0xFFE6EBF2, v -> { call("PSLite.preset", "max"); selectTab(2); }));
        col.addView(pr);

        col.addView(bigBtn1(liteAdv ? "▲ Ẩn tuỳ chỉnh chi tiết" : "▼ Tuỳ chỉnh chi tiết", 0xFF1D2530, 0xFFE6EBF2,
                v -> { liteAdv = !liteAdv; selectTab(2); }));
        if (!liteAdv) return;

        col.addView(liteSwitch("Tắt bóng / blur", "shadow", lite));
        col.addView(liteSwitch("Tắt glow", "glow", lite));
        col.addView(liteSwitch("Tắt số damage / bụi", "part", lite));
        col.addView(liteSwitch("CSS không animation", "css", lite));
        col.addView(liteSwitch("Pixel art (không làm mịn)", "pixel", lite));
        col.addView(liteSwitch("Không vẽ nền map", "bg", lite));

        col.addView(muted("Độ phân giải (dpr)"));
        final double[] dprs = {0, 0.5, 0.75, 1};
        int di = 0;
        for (int i = 0; i < dprs.length; i++) if (Math.abs(dprs[i] - lite.optDouble("dpr", 0)) < 0.001) di = i;
        col.addView(segment(new String[]{"Gốc", "0.5", "0.75", "1"}, di, i -> call("PSLite.set", j("dpr", dprs[i]))));

        col.addView(muted("Bỏ khung hình (vẽ 1 trên N khung)"));
        col.addView(segment(new String[]{"1", "2", "3", "4"}, Math.max(0, Math.min(3, lite.optInt("skip", 1) - 1)),
                i -> call("PSLite.set", j("skip", i + 1))));

        col.addView(muted("Ẩn địch"));
        col.addView(segment(new String[]{"Tắt", "Ở xa", "Tất cả"}, Math.max(0, Math.min(2, lite.optInt("hide", 0))),
                i -> call("PSLite.set", j("hide", i))));

        col.addView(muted("Giới hạn FPS (làm chậm game)"));
        final int[] fpss = {0, 45, 30, 20};
        int fi = 0;
        for (int i = 0; i < fpss.length; i++) if (fpss[i] == lite.optInt("fps", 0)) fi = i;
        col.addView(segment(new String[]{"Tắt", "45", "30", "20"}, fi, i -> call("PSLite.set", j("fps", fpss[i]))));
    }

    // ----- tab 4: Tài khoản (tự điền tài khoản + mật khẩu rồi đăng nhập) -----
    private void buildAccountTab() {
        final Dialog d = menuDlg;
        final String host = server == null ? null : server.activeHost();
        final String pref = prefs.getString("acctSite", null);
        final String site = pref != null ? pref : (host != null && !host.isEmpty() ? siteKey(host) : "main");
        final String[] saved = loadCred(site);
        LinearLayout col = menuBody;

        col.addView(muted("Tài khoản cho trang"));
        col.addView(segment(new String[]{"pokesurvivor.com", "doofcraft"}, site.equals("doof") ? 1 : 0, i -> {
            prefs.edit().putString("acctSite", i == 1 ? "doof" : "main").apply();
            selectTab(3);
        }));
        final EditText eu = field("Tên đăng nhập / email", false);
        final EditText ep = field("Mật khẩu", true);
        if (saved != null) {
            eu.setText(saved[0]);
            ep.setHint("•••••••• (đã lưu, để trống = giữ nguyên)");
        }
        col.addView(eu, new LinearLayout.LayoutParams(-1, -2));
        col.addView(ep, new LinearLayout.LayoutParams(-1, -2));
        col.addView(sw("Hiện mật khẩu", false, (b, on) -> {
            int sel = ep.getSelectionStart();
            ep.setInputType(InputType.TYPE_CLASS_TEXT | (on ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            if (sel >= 0) ep.setSelection(sel);
        }));

        col.addView(bigBtn1("💾 Lưu & đăng nhập ngay", 0xFF1F4A33, 0xFF7EE2A8, v -> {
            String u = eu.getText().toString().trim();
            String p = ep.getText().toString();
            if (p.isEmpty() && saved != null) p = saved[1];
            if (u.isEmpty() || p.isEmpty()) { toast("Nhập đủ tài khoản và mật khẩu"); return; }
            if (!saveCred(site, u, p)) { toast("Không lưu được (máy không hỗ trợ khoá bảo mật)"); return; }
            d.dismiss();
            if (!needConn(true)) return;
            toast("Đang đăng nhập vào " + (host == null || host.isEmpty() ? "trang đang mở" : host) + "…");
            runLogin(u, p, false);
            ui.postDelayed(() -> getv("__TT.loginStatus",
                    r -> toast(r == null ? "Chưa tải xong trang, thử lại" : String.valueOf(r))), 4000);
        }));
        col.addView(sw("Tự đăng nhập khi mở game", prefs.getBoolean("autoLogin", false),
                (b, on) -> prefs.edit().putBoolean("autoLogin", on).apply()));
        col.addView(bigBtn1("Xoá tài khoản đã lưu", 0xFF4D2429, 0xFFFF9A9A, v -> {
            prefs.edit().remove("cred_" + site).apply();
            toast("Đã xoá tài khoản đã lưu");
            selectTab(3);
        }));
        col.addView(muted("Mật khẩu được mã hoá bằng khoá bảo mật của máy và chỉ được điền vào chính trang game. "
                + "Nếu game chỉ có đăng nhập bằng Google thì tính năng này không dùng được."));
    }

    // ----- tab 5: Cài đặt -----
    private void buildAppTab() {
        final Dialog d = menuDlg;
        LinearLayout col = menuBody;
        String host = server == null ? null : server.activeHost();

        col.addView(section("Kết nối trình duyệt"));
        col.addView(muted(host != null && !host.isEmpty() ? "Đang kết nối với: " + host : "Chưa có trang game nào kết nối."));
        LinearLayout n1 = row();
        n1.addView(bigBtn("pokesurvivor.com", 0xFF1D2530, 0xFFE6EBF2, v -> { d.dismiss(); openUrl(HOME_DEFAULT); }));
        n1.addView(bigBtn("doofcraft", 0xFF1D2530, 0xFFE6EBF2, v -> { d.dismiss(); openUrl(HOME_DOOF); }));
        n1.addView(bigBtn("⟳ Tải lại", 0xFF1D2530, 0xFFE6EBF2, v -> {
            d.dismiss();
            if (needConn(true)) rpc(null, "reload", null, null, null, null);
        }));
        col.addView(n1);
        col.addView(bigBtn1("Sao chép link userscript (Firefox / Kiwi)", 0xFF16304F, 0xFF7DBBFF,
                v -> copy("userscript", Cfg.userscriptUrl(this), "Đã sao chép link userscript")));
        col.addView(bigBtn1("Sao chép bookmarklet (Chrome)", 0xFF16304F, 0xFF7DBBFF,
                v -> copy("bookmarklet", Cfg.bookmarklet(this), "Đã sao chép bookmarklet")));
        col.addView(muted("Firefox/Kiwi + Violentmonkey: dán link userscript vào thanh địa chỉ để cài; đầy đủ mọi tính năng, tự kết nối mỗi lần mở game. "
                + "Chrome: bookmarklet chỉ nạp script SAU khi trang đã tải, nên Gacha / Upgrade / Shop / Đăng nhập chạy được, "
                + "còn Bot và Giảm lag cần hook từ lúc trang bắt đầu tải nên thường không hoạt động."));

        col.addView(section("Ứng dụng"));
        col.addView(sw("Giữ màn hình sáng", prefs.getBoolean("keepAwake", true), (b, on) -> {
            prefs.edit().putBoolean("keepAwake", on).apply();
            applyKeepAwake();
        }));
        col.addView(sw("Ẩn bảng điều khiển trong trang", prefs.getBoolean("hidePanel", true), (b, on) -> {
            prefs.edit().putBoolean("hidePanel", on).apply();
            callQ("__TT.hide", on);
        }));
        LinearLayout n2 = row();
        n2.addView(bigBtn("Thoát app (tắt menu nổi)", 0xFF1D2530, 0xFFE6EBF2, v -> { d.dismiss(); stopSelf(); }));
        col.addView(n2);
    }

    private void setRun(String key, String val) {
        if (!needConn(true) || server == null) return;
        JSONObject c = new JSONObject();
        try {
            c.put("op", "run");
            c.put("key", key);
            c.put("val", val);
        } catch (JSONException e) {
            return;
        }
        server.send(c, null, null);
    }

    private int idx(String[] arr, String v) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(v)) return i;
        return 0;
    }

    // ---------- helpers dựng UI ----------
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(0xFF8FB4FF);
        tv.setTextSize(16);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    // Nút to (52dp) trong hàng ngang, chia đều chiều rộng
    private Button bigBtn(String t, int bgc, int fg, View.OnClickListener l) {
        Button b = btn(t, bgc, fg, l);
        b.setTextSize(14);
        b.setMinimumHeight(dp(52));
        return b;
    }

    // Nút to chiếm cả chiều rộng khi đặt trong cột dọc
    private Button bigBtn1(String t, int bgc, int fg, View.OnClickListener l) {
        Button b = bigBtn(t, bgc, fg, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(2), dp(4), dp(2), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private EditText field(String hint, boolean pass) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF6B7684);
        e.setTextColor(Color.WHITE);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setMinHeight(dp(48));
        e.setInputType(InputType.TYPE_CLASS_TEXT | (pass ? InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS));
        e.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_DONE);
        e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        return e;
    }

    private TextView section(String t) {
        TextView tv = new TextView(this);
        tv.setText(t.toUpperCase());
        tv.setTextColor(0xFF8D99A8);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(10), 0, dp(2));
        return tv;
    }

    private TextView muted(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(0xFFB9C3D0);
        tv.setTextSize(12);
        tv.setPadding(0, dp(3), 0, dp(1));
        return tv;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private Button btn(String t, View.OnClickListener l) {
        return btn(t, 0xFF1D2530, 0xFFE6EBF2, l);
    }

    private Button btn(String t, int bgc, int fg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(fg);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(dp(44));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bgc);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), 0xFF3A4553);
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private Switch sw(String t, boolean on, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(this);
        s.setText(t);
        s.setTextColor(0xFFE6EBF2);
        s.setTextSize(13);
        s.setChecked(on);
        s.setPadding(0, dp(8), 0, dp(8));
        s.setMinHeight(dp(48));
        s.setOnCheckedChangeListener(l);
        return s;
    }

    private Switch liteSwitch(String t, final String key, JSONObject lite) {
        return sw(t, lite.optBoolean(key), (b, on) -> call("PSLite.set", j(key, on)));
    }

    // Hàng nút chọn 1 trong N; nút đang chọn được tô vàng
    private LinearLayout segment(String[] labels, int selected, IntConsumer pick) {
        final LinearLayout l = row();
        final Button[] bs = new Button[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            bs[i] = btn(labels[i], v -> {
                for (int j = 0; j < bs.length; j++) paint(bs[j], j == idx);
                pick.accept(idx);
            });
            paint(bs[i], i == selected);
            l.addView(bs[i]);
        }
        return l;
    }

    private void paint(Button b, boolean sel) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(sel ? 0xFF16304F : 0xFF1D2530);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), sel ? 0xFF4DA3FF : 0xFF3A4553);
        b.setBackground(g);
        b.setTextColor(sel ? 0xFF7DBBFF : 0xFFE6EBF2);
    }
}
