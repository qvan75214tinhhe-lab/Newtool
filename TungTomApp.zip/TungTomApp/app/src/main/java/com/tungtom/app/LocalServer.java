package com.tungtom.app;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/**
 * Máy chủ HTTP nhỏ chỉ nghe ở 127.0.0.1. Trang game (trong trình duyệt) kết nối vào đây:
 *  - /payload.js, /TrollModPoke.user.js : nội dung script (bridge + bot + kênh liên lạc)
 *  - /poll  : trang chờ lệnh (long-poll)      - /result : trang trả kết quả      - /vis : báo tab đang hiện/ẩn
 * Mọi yêu cầu phải kèm token ngẫu nhiên (tham số t) sinh ra riêng cho máy này.
 */
final class LocalServer {
    static final int PORT = 38765;
    static volatile LocalServer current;

    interface HelloListener { void onHello(String pid, String host); }

    private static class Page { String id; String host = ""; boolean visible; long seen; long helloAt; }
    private static class Cmd { long id; String json; String pid; Consumer<Object> cb; }

    private final Context ctx;
    private final String token;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Object lock = new Object();
    private final Map<String, Page> pages = new HashMap<>();
    private final LinkedList<Cmd> queue = new LinkedList<>();
    private final Map<Long, Cmd> waiting = new HashMap<>();
    private long seq = 1;
    private ServerSocket ss;
    private volatile boolean running;
    private volatile HelloListener helloListener;
    private String payloadCache;

    LocalServer(Context ctx, String token) {
        this.ctx = ctx.getApplicationContext();
        this.token = token;
    }

    void setHelloListener(HelloListener l) { helloListener = l; }

    boolean start() {
        try {
            ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(InetAddress.getByAddress(new byte[]{127, 0, 0, 1}), PORT));
        } catch (IOException e) {
            return false;
        }
        running = true;
        current = this;
        pool.execute(() -> {
            while (running) {
                try {
                    final Socket s = ss.accept();
                    pool.execute(() -> serve(s));
                } catch (IOException e) {
                    if (!running) break;
                }
            }
        });
        return true;
    }

    void stop() {
        running = false;
        if (current == this) current = null;
        try { if (ss != null) ss.close(); } catch (IOException ignored) {}
        synchronized (lock) { lock.notifyAll(); }
        pool.shutdownNow();
    }

    // ---------- trạng thái kết nối ----------
    boolean connected() {
        synchronized (lock) { return target() != null; }
    }

    String activeHost() {
        synchronized (lock) {
            Page p = target();
            return p == null ? null : p.host;
        }
    }

    // gọi khi đang giữ lock: trang nhận lệnh = tab đang hiện, mới nhất
    private Page target() {
        long now = System.currentTimeMillis();
        Page best = null;
        for (Iterator<Page> it = pages.values().iterator(); it.hasNext(); ) {
            Page p = it.next();
            if (now - p.seen > 45000) { it.remove(); continue; }
            if (best == null || (p.visible && !best.visible) || (p.visible == best.visible && p.helloAt > best.helloAt)) best = p;
        }
        return best;
    }

    // ---------- gửi lệnh tới trang; cb chạy trên luồng UI (null nếu không có trang / quá 8 giây) ----------
    void send(JSONObject cmd, String pid, Consumer<Object> cb) {
        Cmd c = null;
        synchronized (lock) {
            boolean ok = pid == null ? target() != null : pages.containsKey(pid);
            if (ok) {
                Cmd n = new Cmd();
                n.id = seq++;
                n.pid = pid;
                n.cb = cb;
                try {
                    cmd.put("id", n.id);
                    n.json = cmd.toString();
                    c = n;
                } catch (JSONException ignored) { }
                if (c != null) {
                    queue.add(c);
                    waiting.put(c.id, c);
                    lock.notifyAll();
                }
            }
        }
        if (c == null) { finish(cb, null); return; }
        final long id = c.id;
        main.postDelayed(() -> {
            Cmd t;
            synchronized (lock) {
                t = waiting.remove(id);
                if (t != null) queue.remove(t);
            }
            if (t != null) finish(t.cb, null);
        }, 8000);
    }

    private void finish(final Consumer<Object> cb, final Object v) {
        if (cb == null) return;
        main.post(() -> cb.accept(v));
    }

    // ---------- xử lý một kết nối ----------
    private void serve(Socket s) {
        try {
            s.setSoTimeout(35000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();
            String line = readLine(in);
            if (line == null) return;
            String[] rl = line.split(" ");
            if (rl.length < 2) return;
            String method = rl[0], target = rl[1];
            int clen = 0;
            String h;
            while ((h = readLine(in)) != null && !h.isEmpty()) {
                int c = h.indexOf(':');
                if (c > 0 && h.substring(0, c).trim().equalsIgnoreCase("content-length")) {
                    try { clen = Integer.parseInt(h.substring(c + 1).trim()); } catch (NumberFormatException ignored) {}
                }
            }
            byte[] body = new byte[0];
            if (clen > 0) {
                if (clen > (1 << 20)) { reply(out, 413, "text/plain", "too big"); return; }
                body = readN(in, clen);
            }
            if ("OPTIONS".equals(method)) { reply(out, 204, "text/plain", ""); return; }

            Uri u = Uri.parse("http://127.0.0.1" + target);
            String path = u.getPath() == null ? "/" : u.getPath();
            if (!token.equals(u.getQueryParameter("t"))) { reply(out, 403, "text/plain", "forbidden"); return; }

            switch (path) {
                case "/ping":
                    reply(out, 200, "text/plain", "ok");
                    break;
                case "/payload.js":
                    reply(out, 200, "application/javascript; charset=utf-8", payload());
                    break;
                case "/TrollModPoke.user.js":
                    reply(out, 200, "text/javascript; charset=utf-8", userscriptHeader() + payload());
                    break;
                case "/poll":
                    handlePoll(u, out);
                    break;
                case "/result":
                    handleResult(body, out);
                    break;
                case "/vis":
                    handleVis(u, out);
                    break;
                default:
                    reply(out, 404, "text/plain", "not found");
            }
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    private void handlePoll(Uri u, OutputStream out) throws IOException {
        String pid = u.getQueryParameter("pid");
        if (pid == null || pid.isEmpty() || pid.length() > 64) { reply(out, 400, "text/plain", "bad"); return; }
        String host = u.getQueryParameter("host");
        boolean vis = "1".equals(u.getQueryParameter("vis"));
        boolean hello = "1".equals(u.getQueryParameter("hello"));
        long now = System.currentTimeMillis();
        boolean isNew;
        synchronized (lock) {
            Page p = pages.get(pid);
            isNew = p == null;
            if (isNew) { p = new Page(); p.id = pid; pages.put(pid, p); }
            p.host = host == null ? "" : host;
            p.visible = vis;
            p.seen = now;
            if (hello || isNew) p.helloAt = now;
        }
        if (hello || isNew) {
            final String fp = pid, fh = host == null ? "" : host;
            main.post(() -> {
                HelloListener l = helloListener;
                if (l != null) l.onHello(fp, fh);
            });
        }
        Cmd got = null;
        long end = now + 25000;
        synchronized (lock) {
            while (running) {
                Page p = pages.get(pid);
                if (p == null) break;
                p.seen = System.currentTimeMillis();
                got = take(pid);
                if (got != null) break;
                long left = end - System.currentTimeMillis();
                if (left <= 0) break;
                try { lock.wait(Math.min(left, 1000)); } catch (InterruptedException e) { break; }
            }
        }
        reply(out, 200, "application/json", got != null ? got.json : "{}");
    }

    // gọi khi đang giữ lock
    private Cmd take(String pid) {
        Page tg = null;
        for (Iterator<Cmd> it = queue.iterator(); it.hasNext(); ) {
            Cmd c = it.next();
            if (c.pid != null) {
                if (c.pid.equals(pid)) { it.remove(); return c; }
            } else {
                if (tg == null) tg = target();
                if (tg != null && tg.id.equals(pid)) { it.remove(); return c; }
            }
        }
        return null;
    }

    private void handleResult(byte[] body, OutputStream out) throws IOException {
        try {
            JSONObject o = new JSONObject(new String(body, StandardCharsets.UTF_8));
            long id = o.optLong("id", -1);
            Object v = o.has("err") ? null : o.opt("v");
            if (v == JSONObject.NULL) v = null;
            Cmd c;
            synchronized (lock) {
                c = waiting.remove(id);
                if (c != null) queue.remove(c);
            }
            if (c != null) finish(c.cb, v);
        } catch (Exception ignored) { }
        reply(out, 200, "text/plain", "ok");
    }

    private void handleVis(Uri u, OutputStream out) throws IOException {
        String pid = u.getQueryParameter("pid");
        boolean vis = "1".equals(u.getQueryParameter("vis"));
        synchronized (lock) {
            Page p = pid == null ? null : pages.get(pid);
            if (p != null) { p.visible = vis; p.seen = System.currentTimeMillis(); if (vis) p.helloAt = Math.max(p.helloAt, p.seen); }
            lock.notifyAll();
        }
        reply(out, 200, "text/plain", "ok");
    }

    // ---------- nội dung script ----------
    private synchronized String payload() {
        if (payloadCache == null) {
            String pre = "window.__TT_HIDE=true;window.__TT_OPT={};window.__TT_MINI={};window.__TT_COMM_CFG={base:'"
                    + Cfg.base() + "',t:'" + token + "'};\n";
            payloadCache = pre + Cfg.asset(ctx, "bridge.js") + "\n" + Cfg.asset(ctx, "TungTom_user.js") + "\n"
                    + Cfg.asset(ctx, "comm.js") + "\n";
        }
        return payloadCache;
    }

    private String userscriptHeader() {
        return "// ==UserScript==\n"
                + "// @name         TrollModPoke (app)\n"
                + "// @namespace    com.tungtom.app\n"
                + "// @version      2.0.0\n"
                + "// @description  Kết nối trang game với menu nổi của app TrollModPoke\n"
                + "// @match        https://pokesurvivor.com/*\n"
                + "// @match        https://www.pokesurvivor.com/*\n"
                + "// @match        https://pokesurvivor.doofcraft.com/*\n"
                + "// @run-at       document-start\n"
                + "// @grant        none\n"
                + "// @inject-into  page\n"
                + "// ==/UserScript==\n";
    }

    // ---------- HTTP thô ----------
    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 8192) break;
        }
        if (c == -1 && b.size() == 0) return null;
        return b.toString("UTF-8");
    }

    private static byte[] readN(InputStream in, int n) throws IOException {
        byte[] buf = new byte[n];
        int off = 0;
        while (off < n) {
            int r = in.read(buf, off, n - off);
            if (r < 0) break;
            off += r;
        }
        return buf;
    }

    private static void reply(OutputStream out, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String status = code == 200 ? "OK" : code == 204 ? "No Content" : code == 403 ? "Forbidden" : code == 404 ? "Not Found" : code == 413 ? "Payload Too Large" : "Bad Request";
        String head = "HTTP/1.1 " + code + " " + status + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + b.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Access-Control-Allow-Origin: *\r\n"
                + "Access-Control-Allow-Private-Network: true\r\n"
                + "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
                + "Access-Control-Allow-Headers: *\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.UTF_8));
        out.write(b);
        out.flush();
    }
}
