package com.tungtom.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.SecureRandom;

/** Cấu hình dùng chung: token của cầu nối cục bộ, nội dung asset, link cài đặt cho trình duyệt. */
final class Cfg {
    private Cfg() {}

    static String token(Context c) {
        SharedPreferences p = c.getSharedPreferences("tt", Context.MODE_PRIVATE);
        String t = p.getString("token", null);
        if (t == null || t.length() < 16) {
            byte[] b = new byte[16];
            new SecureRandom().nextBytes(b);
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x & 0xff));
            t = sb.toString();
            p.edit().putString("token", t).apply();
        }
        return t;
    }

    static String asset(Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    static String base() {
        return "http://127.0.0.1:" + LocalServer.PORT;
    }

    /** Link cài userscript (Firefox + Violentmonkey, Kiwi...). */
    static String userscriptUrl(Context c) {
        return base() + "/TrollModPoke.user.js?t=" + token(c);
    }

    /** Bookmarklet cho Chrome: nạp script vào trang đang mở (không chạy được lúc document-start). */
    static String bookmarklet(Context c) {
        return "javascript:(function(){try{var s=document.createElement('script');s.src='" + base() + "/payload.js?t="
                + token(c) + "';(document.head||document.documentElement).appendChild(s)}catch(e){alert(e)}})();void 0";
    }
}
