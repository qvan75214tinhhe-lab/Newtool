// Cầu nối app <-> trang.
//  1) Ẩn/hiện bảng điều khiển gốc của userscript (menu đã chuyển sang app).
//  2) Bản thu nhỏ của trang: snap(w) trả ảnh (data URL) cho menu; touch() chuyển chạm trên khung thành chạm trên trang.
//  3) login()/autoLogin(): tự điền tài khoản + mật khẩu vào form đăng nhập của trang rồi bấm nút đăng nhập.
// window.__TT_HIDE và window.__TT_MINI do MainActivity đặt ngay trước file này.
(function () {
  if (window.__TT) return;

  // ---------- 1) ẩn bảng điều khiển gốc ----------
  var st = null;
  function apply() {
    var root = document.head || document.documentElement;
    if (!root) return;
    if (window.__TT_HIDE && !st) {
      st = document.createElement('style');
      st.textContent = '[data-psbot-dock]{display:none!important}';
      root.appendChild(st);
    } else if (!window.__TT_HIDE && st) {
      st.remove();
      st = null;
    }
  }

  // ---------- 2) bản thu nhỏ của trang (hiện trong menu của app) ----------
  // Lấy hàm vẽ gốc NGAY bây giờ (bridge chạy trước userscript): lớp lite/bot của userscript sẽ bọc
  // CanvasRenderingContext2D.prototype.drawImage sau đó, ta không muốn bản thu nhỏ bị chúng lọc hay ghi nhận.
  var nativeDraw = CanvasRenderingContext2D.prototype.drawImage;
  var DEF = { style: 'full', mode: 'page' };
  var cfg = {};
  var cv = null, g = null, items = [], itemsAt = -1e9;
  var PW = 420;   // chiều rộng ảnh xem trước (px)

  function mergeCfg(o) {
    for (var k in DEF) cfg[k] = (o && o[k] !== undefined) ? o[k] : (cfg[k] !== undefined ? cfg[k] : DEF[k]);
  }

  var SKIP = /^(SCRIPT|STYLE|LINK|META|HEAD|TITLE|NOSCRIPT|BR|TEMPLATE|OPTION)$/;

  // Quét DOM thành danh sách hình đơn giản theo thứ tự tài liệu. Chậm hơn nên chỉ làm vài lần/giây.
  function scan() {
    var out = [], n = 0, VW = innerWidth, VH = innerHeight;
    var tw = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    var el;
    while ((el = tw.nextNode()) && n < 700) {
      if (SKIP.test(el.tagName) || el.closest('[data-psbot-ui],[data-tt-mini]')) continue;
      var r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2 || r.right < 0 || r.bottom < 0 || r.left > VW || r.top > VH) continue;
      var cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') continue;
      var tag = el.tagName, it = null;
      if (tag === 'CANVAS') {
        out.push({ t: 'cv', el: el, r: r }); n++; continue;
      }
      var bg = cs.backgroundColor, hasBg = bg && bg !== 'transparent' && !/rgba\(.*,\s*0\)$/.test(bg);
      var bw = parseFloat(cs.borderTopWidth) || 0, hasBd = bw > 0 && cs.borderTopStyle !== 'none';
      var rad = parseFloat(cs.borderTopLeftRadius) || 0;
      if (tag === 'IMG' || tag === 'VIDEO' || tag === 'SVG' || tag === 'svg') {
        out.push({ t: 'media', r: r, rad: rad }); n++;
      } else if (hasBg || hasBd || tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' || tag === 'BUTTON') {
        out.push({ t: 'box', r: r, rad: rad, bg: hasBg ? bg : null, bd: hasBd ? cs.borderTopColor : (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' ? '#889' : null) });
        n++;
      }
      // chữ: node text trực tiếp của phần tử này -> vẽ thành các vạch
      var txt = '';
      for (var c = el.firstChild; c; c = c.nextSibling) if (c.nodeType === 3) txt += c.nodeValue;
      txt = txt.replace(/\s+/g, ' ').trim();
      if (!txt && (tag === 'INPUT' || tag === 'TEXTAREA')) txt = (el.value || el.placeholder || '').trim();
      if (txt) {
        var fs = parseFloat(cs.fontSize) || 12, lh = parseFloat(cs.lineHeight) || fs * 1.25;
        var lines = Math.max(1, Math.min(6, Math.round(r.height / lh)));
        var wpx = Math.min(r.width, txt.length * fs * 0.52 / lines + fs);
        out.push({ t: 'txt', x: r.left + (tag === 'BUTTON' || cs.textAlign === 'center' ? (r.width - wpx) / 2 : 0), y: r.top, w: wpx, lines: lines, lh: lh, fs: fs, col: cs.color });
        n++;
      }
    }
    return out;
  }

  function rr(ctx, x, y, w, h, rad) {
    if (rad > 1 && ctx.roundRect) { ctx.beginPath(); ctx.roundRect(x, y, w, h, Math.min(rad, w / 2, h / 2)); return true; }
    return false;
  }

  function gameCanvas() {
    return document.getElementById('game') || document.querySelector('canvas.ps-canvas') ||
      document.querySelector('canvas:not([data-psbot-ui])');
  }

  function drawCanvas(c, r, k) {
    try { nativeDraw.call(g, c, r.left * k, r.top * k, r.width * k, r.height * k); } catch (e) {}
  }

  function posterize() {
    try {
      var im = g.getImageData(0, 0, cv.width, cv.height), d = im.data;
      for (var i = 0; i < d.length; i += 4) {
        d[i] = (d[i] + 32) >> 6 << 6; d[i + 1] = (d[i + 1] + 32) >> 6 << 6; d[i + 2] = (d[i + 2] + 32) >> 6 << 6;
      }
      g.putImageData(im, 0, 0);
    } catch (e) {}
  }

  function render() {
    if (!cv) { cv = document.createElement('canvas'); cv.setAttribute('data-psbot-ui', ''); g = cv.getContext('2d'); }
    var W = PW, H = Math.max(30, Math.round(PW * innerHeight / Math.max(1, innerWidth)));
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    var k = W / Math.max(1, innerWidth);
    g.globalAlpha = 1;
    g.fillStyle = (getComputedStyle(document.body).backgroundColor || '#000');
    if (g.fillStyle === 'rgba(0, 0, 0, 0)') g.fillStyle = '#0b0f14';
    g.fillRect(0, 0, W, H);
    g.imageSmoothingEnabled = cfg.style !== 'simple';

    if (cfg.mode === 'canvas') {
      var gc = gameCanvas();
      if (gc) {
        var r0 = gc.getBoundingClientRect();
        drawCanvas(gc, r0, k);
      }
    } else {
      var now = performance.now();
      if (now - itemsAt > 450) { items = scan(); itemsAt = now; }
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it.t === 'cv') { drawCanvas(it.el, it.el.getBoundingClientRect(), k); continue; }
        if (it.t === 'txt') {
          g.fillStyle = it.col; g.globalAlpha = 0.85;
          var bh = Math.max(1, it.fs * 0.55 * k);
          for (var l = 0; l < it.lines; l++) {
            var ww = l === it.lines - 1 && it.lines > 1 ? it.w * 0.6 : it.w;
            g.fillRect(it.x * k, (it.y + l * it.lh + (it.lh - it.fs * 0.55) / 2) * k, Math.max(1, ww * k), bh);
          }
          g.globalAlpha = 1; continue;
        }
        var x = it.r.left * k, y = it.r.top * k, w = it.r.width * k, h = it.r.height * k;
        if (it.t === 'media') {
          g.fillStyle = '#5a6577'; g.strokeStyle = '#9aa7ba';
          if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); }
          g.fill(); g.stroke(); continue;
        }
        if (it.bg) { g.fillStyle = it.bg; if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); } g.fill(); }
        if (it.bd) { g.strokeStyle = it.bd; if (!rr(g, x, y, w, h, it.rad * k)) { g.beginPath(); g.rect(x, y, w, h); } g.stroke(); }
      }
    }
    if (cfg.style === 'simple') posterize();
  }

  // snap(w): ảnh thu nhỏ của trang, rộng w px. Kiểu "đơn giản" dùng PNG (ít màu), còn lại JPEG cho nhẹ.
  function snap(w) {
    if (!document.body) return null;
    PW = Math.max(120, Math.min(1280, w | 0 || 420));
    render();
    return cv.toDataURL(cfg.style === 'simple' ? 'image/png' : 'image/jpeg', 0.6);
  }

  // ---------- 3) chạm/kéo trên bản thu nhỏ = chạm/kéo trên trang thật ----------
  // Tọa độ chuẩn hoá 0..1. Mô phỏng một cú chạm thật: pointer + touch (+ mouse/click nếu là chạm nhanh, không kéo).
  var tch = null, tid = 0;
  function ptrEv(type, x, y, id, down) {
    return new PointerEvent(type, { bubbles: true, cancelable: true, composed: true, view: window,
      clientX: x, clientY: y, screenX: x, screenY: y, pointerId: 100 + id, pointerType: 'touch', isPrimary: true,
      width: 1, height: 1, pressure: down ? 0.5 : 0, button: type === 'pointermove' ? -1 : 0, buttons: down ? 1 : 0 });
  }
  function touchEv(type, x, y, id, target) {
    var t = new Touch({ identifier: id, target: target, clientX: x, clientY: y, pageX: x + scrollX, pageY: y + scrollY, screenX: x, screenY: y });
    var end = type === 'touchend' || type === 'touchcancel';
    return new TouchEvent(type, { bubbles: true, cancelable: true, composed: true, view: window,
      touches: end ? [] : [t], targetTouches: end ? [] : [t], changedTouches: [t] });
  }
  function mouseEv(type, x, y, down) {
    return new MouseEvent(type, { bubbles: true, cancelable: true, composed: true, view: window,
      clientX: x, clientY: y, screenX: x, screenY: y, button: 0, buttons: down ? 1 : 0 });
  }
  function send(el, mk) { try { el.dispatchEvent(mk()); } catch (e) {} }
  function touch(phase, nx, ny) {
    var x = Math.round(Math.max(0, Math.min(1, nx)) * (innerWidth - 1));
    var y = Math.round(Math.max(0, Math.min(1, ny)) * (innerHeight - 1));
    if (phase === 'down') {
      var el = document.elementFromPoint(x, y) || document.body;
      tch = { el: el, x: x, y: y, moved: false, id: ++tid };
      send(el, function () { return ptrEv('pointerdown', x, y, tch.id, true); });
      send(el, function () { return touchEv('touchstart', x, y, tch.id, el); });
      return;
    }
    if (!tch) return;
    var s = tch, t = s.el;
    if (phase === 'move') {
      if (Math.abs(x - s.x) + Math.abs(y - s.y) > 12) s.moved = true;
      send(t, function () { return ptrEv('pointermove', x, y, s.id, true); });
      send(t, function () { return touchEv('touchmove', x, y, s.id, t); });
      return;
    }
    var cancel = phase === 'cancel';
    send(t, function () { return ptrEv(cancel ? 'pointercancel' : 'pointerup', x, y, s.id, false); });
    send(t, function () { return touchEv(cancel ? 'touchcancel' : 'touchend', x, y, s.id, t); });
    if (!cancel && !s.moved) {
      send(t, function () { return mouseEv('mousemove', x, y, false); });
      send(t, function () { return mouseEv('mousedown', x, y, true); });
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) { try { t.focus(); } catch (e) {} }
      send(t, function () { return mouseEv('mouseup', x, y, false); });
      send(t, function () { return mouseEv('click', x, y, false); });
    }
    tch = null;
  }

  // ---------- 4) tự điền tài khoản + mật khẩu và đăng nhập ----------
  // Tìm ô mật khẩu đang hiện, ô tài khoản đứng ngay trước nó, điền (kiểu React/Vue cũng nhận), rồi bấm nút đăng nhập.
  var loginStatus = '', autoDone = false;
  function vis(el) {
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0';
  }
  function setVal(el, v) {
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var d = Object.getOwnPropertyDescriptor(proto, 'value');
    try { el.focus(); } catch (e) {}
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  var TXT = /^(text|email|tel|search|url|)$/i;
  // So khớp chữ không dấu (tiếng Việt có thể mã hoá theo nhiều kiểu): "Đăng nhập" -> "dang nhap"
  function plain(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[đĐ]/g, 'd').toLowerCase(); }
  var USER_RE = /user|email|mail|login|account|tai.?khoan|ten/;
  function findFields() {
    var all = [].slice.call(document.querySelectorAll('input')).filter(function (i) { return vis(i) && !i.disabled && !i.readOnly; });
    var pw = null, k;
    for (k = 0; k < all.length; k++) if (all[k].type === 'password') { pw = all[k]; break; }
    if (!pw) return null;
    var before = null;
    for (k = all.indexOf(pw) - 1; k >= 0; k--) if (TXT.test(all[k].type || '')) { before = all[k]; break; }
    var named = all.filter(function (i) {
      return i !== pw && TXT.test(i.type || '') && (!pw.form || i.form === pw.form) &&
        USER_RE.test(plain((i.name || '') + ' ' + (i.id || '') + ' ' + (i.autocomplete || '') + ' ' + (i.placeholder || '')));
    })[0];
    return { pw: pw, user: named || before };
  }
  var GO_RE = /log\s*in|sign\s*in|dang\s*nhap|submit|continue|tiep\s*tuc|vao|enter|play/;
  var BAD_RE = /google|facebook|apple|discord|github|register|sign\s*up|dang\s*ky|guest|khach|forgot|quen/;
  function btnText(b) { return plain((b.innerText || b.value || b.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim()); }
  function submit(pw) {
    var node = pw.form || pw.parentElement, hops = 0, pick = null;
    while (node && !pick && hops++ < 6) {
      var bs = [].slice.call(node.querySelectorAll('button,input[type=submit],input[type=button],[role=button]'))
        .filter(function (b) { return vis(b) && !b.disabled && !BAD_RE.test(btnText(b)); });
      pick = bs.filter(function (b) { return b.type === 'submit'; })[0] || bs.filter(function (b) { return GO_RE.test(btnText(b)); })[0] || null;
      node = node.parentElement;
    }
    if (pick) { pick.click(); return; }
    if (pw.form) { try { pw.form.requestSubmit(); } catch (e) { pw.form.submit(); } return; }
    ['keydown', 'keypress', 'keyup'].forEach(function (t) {
      pw.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    });
  }
  function clickOpener() {
    var c = [].slice.call(document.querySelectorAll('button,a,[role=button]')).filter(function (b) {
      return vis(b) && /^(log\s*in|sign\s*in|dang\s*nhap)$/.test(btnText(b));
    })[0];
    if (c) c.click();
  }
  function attempt(u, p, timeout, allowOpen) {
    var t0 = Date.now(), opened = false;
    loginStatus = 'Đang tìm ô đăng nhập…';
    (function step() {
      var f = null;
      try { f = findFields(); } catch (e) {}
      if (f) {
        try {
          if (f.user) setVal(f.user, u);
          setVal(f.pw, p);
          loginStatus = f.user ? 'Đã điền tài khoản + mật khẩu và gửi đăng nhập' : 'Đã điền mật khẩu (không thấy ô tài khoản) và gửi đăng nhập';
          setTimeout(function () {
            try { submit(f.pw); } catch (e) { loginStatus = 'Đã điền nhưng không bấm được nút đăng nhập'; }
          }, 250);
        } catch (e) { loginStatus = 'Lỗi khi điền form: ' + e.message; }
        return;
      }
      var el = Date.now() - t0;
      if (allowOpen && !opened && el > 800) { opened = true; try { clickOpener(); } catch (e) {} }
      if (el > timeout) { loginStatus = 'Không thấy ô mật khẩu trên trang (nếu game chỉ có đăng nhập bằng Google thì tính năng này không dùng được)'; return; }
      setTimeout(step, 300);
    })();
  }

  // ---------- 5) điều khiển giao diện CHÍNH của game: gacha / upgrade / shop ----------
  // Chỉ bấm đúng các nút trên màn hình game như người chơi (không sửa save, không gọi thẳng API của game).
  // Tìm nút theo id / data-go / chữ hiển thị (không dấu), nên cần "Dò giao diện" nếu game đặt tên khác.
  var CLICKABLE = 'button,[role=button],a,[data-go],[data-tab],[data-gen],.tab,.btn,summary,label';
  var OPT = window.__TT_OPT || {};
  var gstatus = '';
  function lab(el) { return plain((el.innerText || el.value || el.getAttribute('aria-label') || el.title || '').replace(/\s+/g, ' ').trim()); }
  function idsOf(el) {
    return plain([el.id, el.getAttribute('data-go'), el.getAttribute('data-tab'), el.getAttribute('data-gen'), el.getAttribute('data-gacha')].join(' '));
  }
  function clickables() {
    return [].slice.call(document.querySelectorAll(CLICKABLE)).filter(function (e) {
      return vis(e) && !e.closest('[data-psbot-ui],[data-psbot-dock]');
    });
  }
  function isEnabled(e) {
    return !e.disabled && e.getAttribute('aria-disabled') !== 'true' && !/(^|\s)(disabled|locked|maxed)(\s|$)/i.test(String(e.className || ''));
  }
  function realClick(el) {
    try { el.scrollIntoView({ block: 'nearest' }); } catch (e) {}
    var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    var mk = function (T, t) { return new T(t, { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0 }); };
    try { el.dispatchEvent(mk(PointerEvent, 'pointerdown')); el.dispatchEvent(mk(MouseEvent, 'mousedown')); } catch (e) {}
    try { el.dispatchEvent(mk(PointerEvent, 'pointerup')); el.dispatchEvent(mk(MouseEvent, 'mouseup')); } catch (e) {}
    el.click();
  }
  var KIND = {
    gacha: /gacha|banner|summon|invoc|ruleta|vong quay|quay so|rut the/,
    shop: /shop|tienda|kecleon|mart|store|cua hang|market/,
    upgrade: /upgrade|mejora|nang cap|talent|perk|power.?up/
  };
  // Mở mục của game: ưu tiên nút menu có data-go, rồi tới mọi nút ngắn có chữ khớp
  function openKind(kind) {
    var re = KIND[kind], cs = clickables(), pick = null;
    pick = cs.filter(function (e) { var g = plain(e.getAttribute('data-go') || ''); return g && re.test(g); })[0] ||
           cs.filter(function (e) { return re.test(idsOf(e)) && lab(e).length < 40; })[0] ||
           cs.filter(function (e) { var l = lab(e); return l && l.length < 28 && re.test(l); })[0];
    if (!pick) return false;
    realClick(pick);
    return true;
  }
  var ROMAN = ['', 'i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix'];
  var REGION = ['', 'kanto', 'johto', 'hoenn', 'sinnoh', 'unova|teselia|unova', 'kalos', 'alola', 'galar', 'paldea'];
  // Chọn "Gen n" ngay trong màn gacha của game (nếu game có bộ chọn thế hệ)
  function pickGen(n) {
    var cs = clickables(), pick = null, sn = String(n);
    pick = cs.filter(function (e) { return e.getAttribute('data-gen') === sn; })[0] ||
      cs.filter(function (e) { return new RegExp('^gen(eration|eracion)?[\\s.:#-]*(' + sn + '|' + ROMAN[n] + ')$').test(lab(e)); })[0] ||
      cs.filter(function (e) { return new RegExp('^(' + REGION[n] + ')\\b').test(lab(e)); })[0] ||
      cs.filter(function (e) {
        if (lab(e) !== sn) return false;
        var par = e.parentElement; if (!par) return false;
        var nums = [].slice.call(par.children).filter(function (c) { return /^[1-9]$/.test(lab(c)); });
        return nums.length >= 3;
      })[0];
    if (!pick) return false;
    realClick(pick);
    return true;
  }
  var BAD_PULL = /close|back|volver|cerrar|dong|quay lai|skip|bo qua|info|rate|tasa|history|historial|lich su|cancel|huy|ok$/;
  function findPull(count) {
    var cs = clickables().filter(function (e) {
      var l = lab(e), i = idsOf(e);
      if (e.hasAttribute('data-go') || e.closest('#scr-menu')) return false;        // mục của menu chính, không phải nút quay
      return !BAD_PULL.test(l) && (/pull|roll|summon|tirar|invoc|quay|rut|spin|draw|abrir|open/.test(l + ' ' + i)) && l.length < 40;
    });
    var ten = cs.filter(function (e) { return /(^|[^0-9])10([^0-9]|$)|x ?10|ten|multi/.test(lab(e) + ' ' + idsOf(e)); });
    var one = cs.filter(function (e) { return ten.indexOf(e) < 0; });
    return (count >= 10 ? ten[0] || one[0] : one[0] || ten[0]) || null;
  }
  // Đóng popup kết quả: ưu tiên nút kiểu "OK / Tiếp tục / Nhận" (lấy nút cuối cùng trong trang = popup nằm trên cùng);
  // chỉ bấm "Đóng / X" khi nút đó nằm trong cửa sổ popup, để không đóng nhầm cả màn gacha
  var OK_RE = /^(ok|okay|continue|aceptar|got it|claim|collect|nhan|tiep tuc|xong|done|great|awesome|tuyet|next|siguiente)\b/;
  var CLOSE_RE = /^(close|cerrar|dong|skip|bo qua|x|✕|×)$/;
  var POPUP_SEL = '.modal,[role=dialog],dialog,.popup,.overlay,[id*=popup],[id*=result],[class*=popup],[class*=result]';
  function dismissPopup() {
    var cs = clickables().filter(isEnabled);
    var d = cs.filter(function (e) { return OK_RE.test(lab(e)); }).pop() ||
            cs.filter(function (e) { return CLOSE_RE.test(lab(e)) && e.closest(POPUP_SEL); }).pop();
    if (d) { realClick(d); return true; }
    return false;
  }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  var busy = false;
  function pauseBot() { var b = window.PSBot && PSBot.state; if (b && b.on) { try { PSBot.pause(); } catch (e) {} return true; } return false; }
  function resumeBot(was) { if (was) { try { PSBot.resume(); } catch (e) {} } }

  // gacha: mở màn gacha (nếu chưa mở), chọn gen, quay "times" lần (count = 1 hoặc 10 con mỗi lần quay)
  function gachaRun(gen, times, count) {
    if (busy) return 'busy';
    busy = true; gstatus = 'Đang mở gacha…';
    var was = pauseBot();
    (async function () {
      try {
        if (!findPull(count)) {
          if (!openKind('gacha')) { gstatus = 'Không thấy nút Gacha trong menu game (vào menu chính rồi thử lại, hoặc bấm "Dò giao diện")'; return; }
          await wait(900);
        }
        if (gen) {
          if (pickGen(gen)) { gstatus = 'Đã chọn Gen ' + gen; await wait(700); }
          else { gstatus = 'Màn gacha của game không có bộ chọn Gen ' + gen + ' — quay bản hiện tại'; await wait(400); }
        }
        var done = 0;
        for (var i = 0; i < times; i++) {
          var b = findPull(count);
          if (!b) { gstatus = 'Không thấy nút quay (đã quay ' + done + ' lần)'; return; }
          if (!isEnabled(b)) { gstatus = 'Không quay được tiếp (hết vé/xu?) — đã quay ' + done + ' lần'; return; }
          realClick(b); done++;
          gstatus = 'Đã quay ' + done + '/' + times;
          await wait(1300);
          for (var k = 0; k < 4 && dismissPopup(); k++) await wait(500);
        }
        gstatus = 'Xong: đã quay ' + done + ' lần' + (gen ? ' (Gen ' + gen + ')' : '');
      } catch (e) { gstatus = 'Lỗi gacha: ' + e.message; }
      finally { busy = false; resumeBot(was); }
    })();
    return 'started';
  }

  // upgrade: bấm lần lượt mọi nút "+" / "Upgrade" còn bấm được trong màn Upgrade của game
  var UP_BTN = /^\+$|^\+ ?\d|upgrade|nang cap|mejorar|subir|level ?up|^add\b|^cong\b|^tang\b|^mua\b|^buy\b|^comprar/;
  var UP_BAD = /max|locked|close|back|volver|cerrar|dong|quay lai|cancel|huy|shop|gacha|play|choi/;
  function upgradeRun(auto) {
    if (busy) return 'busy';
    busy = true; gstatus = 'Đang mở Upgrade…';
    var was = pauseBot();
    (async function () {
      var clicks = 0;
      try {
        if (!openKind('upgrade')) { gstatus = 'Không thấy mục Upgrade trong menu game (bấm "Dò giao diện" rồi gửi lại cho mình)'; return; }
        await wait(900);
        for (var i = 0; i < 80; i++) {
          var b = clickables().filter(function (e) { var l = lab(e); return UP_BTN.test(l) && !UP_BAD.test(l) && isEnabled(e); })[0];
          if (!b) break;
          realClick(b); clicks++;
          await wait(200);
          var cf = clickables().filter(function (e) { return /^(ok|aceptar|confirm|confirmar|xac nhan|yes)\b/.test(lab(e)); })[0];
          if (cf) realClick(cf);
        }
        gstatus = clicks ? 'Upgrade: đã cộng ' + clicks + ' lần' : 'Upgrade: không có điểm nào bấm được';
        // đóng màn Upgrade nếu là cửa sổ phủ lên menu
        var back = clickables().filter(function (e) { return /^(close|back|volver|cerrar|dong|quay lai|x|✕|×)$/.test(lab(e)); })[0];
        if (back) { realClick(back); await wait(500); }
      } catch (e) { gstatus = 'Lỗi upgrade: ' + e.message; }
      finally { busy = false; resumeBot(was); }
    })();
    return 'started';
  }

  function openShop() { var ok = openKind('shop'); gstatus = ok ? 'Đã mở shop của game' : 'Không thấy nút Shop trong menu game (vào menu chính rồi thử lại)'; return ok; }

  // Dò giao diện: liệt kê màn hình đang mở + các nút nhìn thấy, để gửi lại khi cần chỉnh cho khớp game
  function scanUi() {
    var out = [], scr = [].slice.call(document.querySelectorAll('[id^=scr-],dialog,[role=dialog],.modal,.overlay,.popup')).filter(function (e) { return !e.classList.contains('hidden') && vis(e); });
    out.push('URL: ' + location.href);
    out.push('Màn đang mở: ' + (scr.map(function (e) { return (e.id || e.className || e.tagName); }).join(', ') || '(không thấy)'));
    var seen = {};
    clickables().slice(0, 140).forEach(function (e) {
      var l = (e.innerText || e.value || e.getAttribute('aria-label') || e.title || '').replace(/\s+/g, ' ').trim().slice(0, 40);
      var line = e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (e.getAttribute('data-go') ? '[go=' + e.getAttribute('data-go') + ']' : '') + (e.getAttribute('data-gen') ? '[gen=' + e.getAttribute('data-gen') + ']' : '') + (isEnabled(e) ? '' : ' (tắt)') + ' "' + l + '"';
      if (!seen[line]) { seen[line] = 1; out.push(line); }
    });
    return out.join('\n');
  }

  // ---------- 6) lưới an toàn: thua xong -> lưu game -> chơi ván tiếp ----------
  // Bot tự làm việc này; nếu màn "thua" / menu cứ đứng yên > 9 giây trong khi bot vẫn bật thì làm thay, dùng các id của game
  // (scr-over, btn-again, btn-save, #scr-menu [data-go=play], các popup scr-savenote / news / nick / recover / video).
  var wd = { since: 0, lastAct: 0, saveAt: 0, upDone: false };
  var POPUPS = [['scr-savenote', 'savenote-ok'], ['scr-news', 'news-close'], ['scr-nick', 'nick-later'], ['scr-recover', 'rec-later'], ['scr-video', 'video-close']];
  function screenOpen(id) { var e = document.getElementById(id); return !!e && !e.classList.contains('hidden') && vis(e); }
  function watchdog() {
    var st = window.PSBot && PSBot.state;
    if (!st || !st.on || busy) { wd.since = 0; return; }
    if (st.target && st.done >= st.target) return;
    var over = screenOpen('scr-over'), menu = screenOpen('scr-menu'), now = Date.now();
    if (!over && !menu) { wd.since = 0; wd.saveAt = 0; wd.upDone = false; return; }
    if (!wd.since) wd.since = now;
    if (now - wd.since < 9000 || now - wd.lastAct < 2500) return;
    for (var i = 0; i < POPUPS.length; i++) {
      if (screenOpen(POPUPS[i][0])) { var pb = document.getElementById(POPUPS[i][1]); if (pb) { realClick(pb); wd.lastAct = now; gstatus = 'Giám sát: đóng popup ' + POPUPS[i][0]; return; } }
    }
    var sb = document.getElementById('btn-save');
    if (sb && !sb.classList.contains('hidden') && vis(sb) && !sb.disabled) {
      if (!wd.saveAt) { realClick(sb); wd.saveAt = now; wd.lastAct = now; gstatus = 'Giám sát: bấm Lưu game'; return; }
      if (now - wd.saveAt < 15000) return;          // chờ lưu xong (tối đa 15 giây)
    }
    if (menu && OPT.autoUpgrade && !wd.upDone) { wd.upDone = true; wd.lastAct = now; upgradeRun(true); return; }
    var go = over ? document.getElementById('btn-again') : document.querySelector('#scr-menu [data-go=play]');
    if (go) { realClick(go); wd.lastAct = now; wd.since = 0; wd.saveAt = 0; gstatus = 'Giám sát: chơi ván tiếp'; }
  }
  setInterval(function () { try { watchdog(); } catch (e) {} }, 1500);

  mergeCfg(window.__TT_MINI);

  window.__TT = {
    hide: function (b) { window.__TT_HIDE = !!b; apply(); },
    mini: {
      set: function (o) { mergeCfg(o); itemsAt = -1e9; },
      get: function () { return JSON.parse(JSON.stringify(cfg)); },
      snap: snap,
      touch: touch
    },
    game: {
      gacha: gachaRun,
      upgrade: function () { return upgradeRun(false); },
      openShop: openShop,
      open: function (k) { return openKind(k); },
      scan: scanUi,
      setOpt: function (o) { for (var k in o) OPT[k] = o[k]; },
      get status() { return gstatus; }
    },
    login: function (u, p) { attempt(String(u), String(p), 8000, true); return 'started'; },
    autoLogin: function (u, p) { if (autoDone) return 'skip'; autoDone = true; attempt(String(u), String(p), 20000, false); return 'started'; },
    get loginStatus() { return loginStatus; }
  };
  apply();
  document.addEventListener('DOMContentLoaded', apply);
})();
